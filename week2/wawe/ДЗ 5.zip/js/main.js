$(function () {
  var mixer = mixitup('.gallery__content');
});