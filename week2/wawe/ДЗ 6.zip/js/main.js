$(function () {
  var mixer = mixitup('.gallery__content');
  $('.slider-blog__inner').slick({
    dots: true,
    arrows: false,
  });
});